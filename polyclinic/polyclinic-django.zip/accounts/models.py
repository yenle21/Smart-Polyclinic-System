from cloudinary.models import CloudinaryField
from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.
class BaseModel(models.Model):
    active = models.BooleanField(default=True)
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True

class User(AbstractUser):
    ROLE_CHOICES = [
        ('patient', 'Bệnh nhân'),
        ('doctor', 'Bác sĩ'),
        ('staff', 'Nhân viên'),
        ('pharmacy','Dược sĩ'),
        ('admin', 'Quản trị viên'),
    ]

    avatar = CloudinaryField(null=True, blank=True)
    phone = models.CharField(max_length=15, null=True, blank=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='patient')

    def __str__(self):
        return self.username

class Patient(BaseModel):
    GENDER_CHOICES = [
        ('male',   'Nam'),
        ('female', 'Nữ'),
    ]

    dob        = models.DateField(null=True)
    gender     = models.CharField(max_length=10, choices=GENDER_CHOICES, null=True)
    address    = models.TextField(null=True)
    full_name = models.CharField(max_length=100)
    user       = models.OneToOneField(User, on_delete=models.CASCADE, related_name='patient_profile')

    def __str__(self):
        return self.full_name or self.user.get_full_name() or self.user.username


class Specialty(BaseModel):
    name        = models.CharField(max_length=100, unique=True)
    description = models.TextField(null=True)


    def __str__(self):
        return self.name


class Doctor(BaseModel):
    user             = models.OneToOneField(User, on_delete=models.CASCADE, related_name='doctor_profile')
    degree           = models.CharField(max_length=100, null=True)
    bio              = models.TextField(null=True)
    consultation_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    specialties = models.ManyToManyField(Specialty, related_name='doctors')    # PROTECT là không cho xóa chuyên khoa, nếu còn bác sĩ thuộc chuyên khoa đó
    def __str__(self):
        return self.user.get_full_name() or self.user.username

